# WordPress MySQL database migration
#
# Generated: Thursday 12. December 2019 10:57 UTC
# Hostname: localhost
# Database: `ff_demo`
# URL: //florafountain.com
# Path: /home/florafountain/public_html/staging
# Tables: ff_cf7_data, ff_cf7_data_entry, ff_commentmeta, ff_comments, ff_itsec_distributed_storage, ff_itsec_fingerprints, ff_itsec_geolocation_cache, ff_itsec_lockouts, ff_itsec_logs, ff_itsec_opaque_tokens, ff_itsec_temp, ff_links, ff_options, ff_popularpostsdata, ff_popularpostssummary, ff_postmeta, ff_posts, ff_sbi_instagram_feeds_posts, ff_sbi_instagram_posts, ff_term_relationships, ff_term_taxonomy, ff_termmeta, ff_terms, ff_toolset_associations, ff_toolset_post_guid_id, ff_toolset_relationships, ff_toolset_type_sets, ff_usermeta, ff_users, ff_wfblockediplog, ff_wfblocks7, ff_wfconfig, ff_wfcrawlers, ff_wffilechanges, ff_wffilemods, ff_wfhits, ff_wfhoover, ff_wfissues, ff_wfknownfilelist, ff_wflivetraffichuman, ff_wflocs, ff_wflogins, ff_wfls_2fa_secrets, ff_wfls_settings, ff_wfnotifications, ff_wfpendingissues, ff_wfreversecache, ff_wfsnipcache, ff_wfstatus, ff_wftrafficrates, ff_yoast_seo_links, ff_yoast_seo_meta
# Table Prefix: ff_
# Post Types: revision, acf-field, acf-field-group, attachment, custom_css, mc4wp-form, nav_menu_item, page, portfolio, post, testimonial, wp-types-group, wpcf7_contact_form
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `ff_cf7_data`
#

DROP TABLE IF EXISTS `ff_cf7_data`;


#
# Table structure of table `ff_cf7_data`
#

CREATE TABLE `ff_cf7_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `ff_cf7_data`
#
INSERT INTO `ff_cf7_data` ( `id`, `created`) VALUES
(1, '2019-08-24 11:30:36') ;

#
# End of data contents of table `ff_cf7_data`
# --------------------------------------------------------



#
# Delete any existing table `ff_cf7_data_entry`
#

DROP TABLE IF EXISTS `ff_cf7_data_entry`;


#
# Table structure of table `ff_cf7_data_entry`
#

CREATE TABLE `ff_cf7_data_entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cf7_id` int(11) NOT NULL,
  `data_id` int(11) NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `ff_cf7_data_entry`
#
INSERT INTO `ff_cf7_data_entry` ( `id`, `cf7_id`, `data_id`, `name`, `value`) VALUES
(1, 43, 1, '_wpcf7_container_post', '0'),
(2, 43, 1, 'g-recaptcha-response', '03AOLTBLS1Qm-JVI4xKa0hecv1Z68uBvQWSMJND3CSimZVQjDNF06lR0B7axrw0pfUplz8MB6R1NxsRJ1qSsfHriJdTZ3WAIIrmuYHLmE0Lu5pfGteOSsIgb3Q6X-5wjKgJK-PgQzY4Dyit6d4QXvCX7cC9OdKpsRDab6IKahhSC14ER2roQm4yKB1ZEWpPU-Jw6ktnhNF2i5dgKl4TOtqI9R7554hGc0gdGlhT1KNrM79tynA7_90KpBejb5sglxfxMsn82K2-h3vnEZHpKiQ87MBEwxRLoYg9mWh9_HtJdtUK_9sASG2rHSlCAD5diPV35LLI3po4KWT7sH0PUv7LbGq0rKsUapjUQ'),
(3, 43, 1, 'FirstName', 'Vasim'),
(4, 43, 1, 'LastName', 'Samadji'),
(5, 43, 1, 'Email', 'samadji.vasim@gmail.com'),
(6, 43, 1, 'PhoneNumber', '9879633944'),
(7, 43, 1, 'WriteMessage', 'hi'),
(8, 43, 1, 'mc4wp_checkbox', 'No'),
(9, 43, 1, 'submit_time', '2019-08-24 17:00:36'),
(10, 43, 1, 'submit_ip', '122.169.84.90'),
(11, 43, 1, 'submit_user_id', '0') ;

#
# End of data contents of table `ff_cf7_data_entry`
# --------------------------------------------------------



#
# Delete any existing table `ff_commentmeta`
#

DROP TABLE IF EXISTS `ff_commentmeta`;


#
# Table structure of table `ff_commentmeta`
#

CREATE TABLE `ff_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `ff_commentmeta`
#

#
# End of data contents of table `ff_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `ff_comments`
#

DROP TABLE IF EXISTS `ff_comments`;


#
# Table structure of table `ff_comments`
#

CREATE TABLE `ff_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


#
# Data contents of table `ff_comments`
#

#
# End of data contents of table `ff_comments`
# --------------------------------------------------------

